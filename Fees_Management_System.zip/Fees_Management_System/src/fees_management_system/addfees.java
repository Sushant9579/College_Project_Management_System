/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fees_management_system;

import java.awt.Color;
import java.sql.*;
import java.text.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Sushant
 */
public class addfees extends javax.swing.JFrame {

    /**
     * Creates new form addfees
     */
    public addfees() {
        initComponents();
        displayCashFirst();
        fillcombobox();
        int receiptNo = getReceipt();
        txt_receipt.setText(Integer.toString(receiptNo));
    }
     
    public void displayCashFirst(){
        
        lbl_dd.setVisible(false);
        lbl_cheque.setVisible(false);
        lbl_bank.setVisible(false);
        
         txt_dd.setVisible(false);
         txt_cheque.setVisible(false);
         txt_bank.setVisible(false);
    }
    public boolean validation(){
        if(txt_recieved.getText().equals("")) {
            JOptionPane.showMessageDialog(this,"Please Enter the Name");
            return false;
        }
        if(datechooser.getDate() == null) {
            JOptionPane.showMessageDialog(this,"Please Select Date");
            return false;
        }
        if(txt_amount.getText().equals("") || txt_amount.getText().matches("[0-9]+") ==false) {
            JOptionPane.showMessageDialog(this,"Please Enter the Amount(In Numbers)");
            return false;
        }
        if(combo_payment.getSelectedItem().toString().equalsIgnoreCase("Cheque")){
            if(txt_cheque.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Please Enter Cheque Number)");
            return false;
                }
            if(txt_bank.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Please Enter the Bank Name");
            return false;
                }
            
        }
        if(combo_payment.getSelectedItem().toString().equalsIgnoreCase("DD")){
            if(txt_dd.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Please Enter DD Number)");
            return false;
                }
            if(txt_bank.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Please Enter the Bank Name");
            return false;
                }
            
        }
        if(combo_payment.getSelectedItem().toString().equalsIgnoreCase("Card")){
            if(txt_bank.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Please Enter the Bank Name");
            return false;
                }
            
        }
        return true;
    }
    public void fillcombobox(){
        try{
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdata","root","root");
             PreparedStatement pst = con.prepareStatement("select cname from course");
             ResultSet rs = pst.executeQuery();
             while(rs.next()){
                 combo_course.addItem(rs.getString("cname"));
             }
           
        }catch(Exception e){
          e.printStackTrace();
        //  e.toString();
          //System.out.println(e);
        }
    }
    public int getReceipt(){
        int receipt = 0;
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select max(reciept_no) from fees_Details");
            ResultSet rs = pst.executeQuery();
            if(rs.next() == true){
              receipt = rs.getInt(1);
            }
        }catch(Exception e){
           e.printStackTrace();
        }
        return receipt+1;
    }
    
    public String insertData(){
        
        String status ="";
        
        int receiptNo = Integer.parseInt(txt_receipt.getText());
        String studentName = txt_recieved.getText();
        String rollno = txt_rollNo.getText();
        String paymentMode = combo_payment.getSelectedItem().toString();
        String chequeNo = txt_cheque.getText();
        String bankname = txt_bank.getText();
        String ddNo = txt_dd.getText();
        String courseName = txt_coursename.getText();
        String gstin = txt_gst.getText();
        float totalamount = Float.parseFloat(txt_total.getText());
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
        String date = dateFormat.format(datechooser.getDate());
        float initialAmount = Float.parseFloat(txt_amount.getText());
        float cgst = Float.parseFloat(txt_cgst.getText());
        float sgst = Float.parseFloat(txt_sgst.getText());
        String totalInWords = txt_totalwords.getText();
        String remark = txt_remark.getText();
        int year1 = Integer.parseInt(txt_year1.getText());
        int year2 = Integer.parseInt(txt_year2.getText());
        
        try{
          Connection con = DBConnection.getConnection();
          PreparedStatement pst =con.prepareStatement("insert into fees_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
          pst.setInt(1, receiptNo);
          pst.setString(2, studentName);
          pst.setString(3,rollno);
          pst.setString(4,paymentMode);
          pst.setString(5,chequeNo);
          pst.setString(6,bankname);
          pst.setString(7,ddNo);
          pst.setString(8,courseName);
          pst.setString(9,gstin);
          pst.setFloat(10,totalamount);
          pst.setString(11,date);
          pst.setFloat(12,initialAmount);
          pst.setFloat(13,cgst);
          pst.setFloat(14,sgst);
          pst.setString(15,totalInWords);
          pst.setString(16,remark);
          pst.setInt(17,year1);
          pst.setInt(18,year2);
          
        int rowCount = pst.executeUpdate();
          if(rowCount == 1){
             status="Sucess"; 
          }else{
              status="Failed";
          }
        }catch(Exception e){
            e.printStackTrace();;
        }
        return status;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlparent = new javax.swing.JPanel();
        txt_gst = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lbl_dd = new javax.swing.JLabel();
        lbl_bank = new javax.swing.JLabel();
        lbl_cheque = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_dd = new javax.swing.JTextField();
        txt_receipt = new javax.swing.JTextField();
        datechooser = new com.toedter.calendar.JDateChooser();
        pnlchild = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txt_rollNo = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txt_amount = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        combo_course = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txt_year1 = new javax.swing.JTextField();
        txt_cgst = new javax.swing.JTextField();
        txt_sgst = new javax.swing.JTextField();
        txt_total = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        txt_coursename = new javax.swing.JTextField();
        txt_totalwords = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_remark = new javax.swing.JTextArea();
        jLabel20 = new javax.swing.JLabel();
        btn_print = new java.awt.Button();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        txt_recieved = new javax.swing.JTextField();
        txt_year2 = new javax.swing.JTextField();
        combo_payment = new javax.swing.JComboBox<>();
        txt_bank = new javax.swing.JTextField();
        txt_cheque = new javax.swing.JTextField();
        pnlsidebar = new javax.swing.JPanel();
        btnsearch = new javax.swing.JPanel();
        btnlblhome2 = new javax.swing.JLabel();
        btnhome = new javax.swing.JPanel();
        btnlblhome = new javax.swing.JLabel();
        btnedit = new javax.swing.JPanel();
        btnlblhome3 = new javax.swing.JLabel();
        btncourse = new javax.swing.JPanel();
        btnlblhome1 = new javax.swing.JLabel();
        btnview = new javax.swing.JPanel();
        btnlblhome6 = new javax.swing.JLabel();
        btnback = new javax.swing.JPanel();
        btnlblhome4 = new javax.swing.JLabel();
        btnlogout = new javax.swing.JPanel();
        btnlblhome5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlparent.setBackground(new java.awt.Color(0, 153, 153));
        pnlparent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_gst.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_gst.setText("SUSHANT8888");
        pnlparent.add(txt_gst, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 50, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Date : ");
        pnlparent.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, -1, -1));

        lbl_dd.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lbl_dd.setText("DD No : ");
        pnlparent.add(lbl_dd, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, 20));

        lbl_bank.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lbl_bank.setText("Bank Name. : ");
        pnlparent.add(lbl_bank, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        lbl_cheque.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lbl_cheque.setText("Cheque No : ");
        pnlparent.add(lbl_cheque, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Mode of Payment : ");
        pnlparent.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel7.setText("COM -");
        pnlparent.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel8.setText("GSTIN : ");
        pnlparent.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel9.setText("Receipt No. : ");
        pnlparent.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        txt_dd.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlparent.add(txt_dd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 180, -1));

        txt_receipt.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlparent.add(txt_receipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 180, -1));
        pnlparent.add(datechooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        pnlchild.setBackground(new java.awt.Color(0, 153, 153));
        pnlchild.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel10.setText("The following payment in the college office for the year : ");
        pnlchild.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel11.setText("to");
        pnlchild.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, -1, -1));

        txt_rollNo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_rollNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 90, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel12.setText("Roll No : ");
        pnlchild.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, -1, -1));

        txt_amount.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txt_amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_amountActionPerformed(evt);
            }
        });
        pnlchild.add(txt_amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 140, 130, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel13.setText("Recieved From : ");
        pnlchild.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        combo_course.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        combo_course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_courseActionPerformed(evt);
            }
        });
        pnlchild.add(combo_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 180, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel14.setText("Amount (Rs.)");
        pnlchild.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, -1, -1));
        pnlchild.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 670, 20));
        pnlchild.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, 200, 20));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel15.setText("Course");
        pnlchild.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel16.setText("SGST : 9%");
        pnlchild.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, -1, -1));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel17.setText("Sr No.");
        pnlchild.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, 20));

        txt_year1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_year1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 40, 80, -1));

        txt_cgst.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_cgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 170, 130, -1));

        txt_sgst.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_sgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 200, 130, -1));

        txt_total.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });
        pnlchild.add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 240, 130, -1));
        pnlchild.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 670, 20));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel18.setText("Heads");
        pnlchild.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, -1, -1));

        txt_coursename.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txt_coursename.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_coursenameActionPerformed(evt);
            }
        });
        pnlchild.add(txt_coursename, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 230, -1));

        txt_totalwords.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_totalwords, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 230, -1));
        pnlchild.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 230, 200, 20));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel19.setText("Receiver Signature  ");
        pnlchild.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 350, -1, -1));

        txt_remark.setColumns(20);
        txt_remark.setRows(5);
        jScrollPane1.setViewportView(txt_remark);

        pnlchild.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, -1, 70));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel20.setText("Total in Words : ");
        pnlchild.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        btn_print.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        btn_print.setLabel("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        pnlchild.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 350, -1, -1));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel21.setText("Remarks : ");
        pnlchild.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel22.setText("CGST : 9%");
        pnlchild.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, -1, -1));

        txt_recieved.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txt_recieved.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_recievedActionPerformed(evt);
            }
        });
        pnlchild.add(txt_recieved, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 290, -1));

        txt_year2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlchild.add(txt_year2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 40, 90, -1));

        pnlparent.add(pnlchild, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 670, 390));

        combo_payment.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        combo_payment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DD", "Cheque", "Cash", "Card" }));
        combo_payment.setSelectedIndex(2);
        combo_payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_paymentActionPerformed(evt);
            }
        });
        pnlparent.add(combo_payment, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, 180, -1));

        txt_bank.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlparent.add(txt_bank, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 180, -1));

        txt_cheque.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pnlparent.add(txt_cheque, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 180, -1));

        getContentPane().add(pnlparent, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 670, 550));

        pnlsidebar.setBackground(new java.awt.Color(0, 102, 102));
        pnlsidebar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnsearch.setBackground(new java.awt.Color(0, 102, 102));
        btnsearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnsearchMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnsearchMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnsearchMouseExited(evt);
            }
        });
        btnsearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome2.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/search3.png"))); // NOI18N
        btnlblhome2.setText("Search");
        btnsearch.add(btnlblhome2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 160, 40));

        btnhome.setBackground(new java.awt.Color(0, 102, 102));
        btnhome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnhome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnhomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnhomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnhomeMouseExited(evt);
            }
        });
        btnhome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/home1.png"))); // NOI18N
        btnlblhome.setText("  Home");
        btnhome.add(btnlblhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 160, 40));

        btnedit.setBackground(new java.awt.Color(0, 102, 102));
        btnedit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btneditMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btneditMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btneditMouseExited(evt);
            }
        });
        btnedit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome3.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/edit1.png"))); // NOI18N
        btnlblhome3.setText("Edit");
        btnedit.add(btnlblhome3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, -1, 40));

        pnlsidebar.add(btnedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 160, 40));

        btncourse.setBackground(new java.awt.Color(0, 102, 102));
        btncourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btncourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btncourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btncourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btncourseMouseExited(evt);
            }
        });
        btncourse.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome1.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/course.png"))); // NOI18N
        btnlblhome1.setText("Course");
        btncourse.add(btnlblhome1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btncourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 160, 40));

        btnview.setBackground(new java.awt.Color(0, 102, 102));
        btnview.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnview.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnviewMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnviewMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnviewMouseExited(evt);
            }
        });
        btnview.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome6.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/view all record.png"))); // NOI18N
        btnlblhome6.setText("Veiw");
        btnview.add(btnlblhome6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnview, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 160, 40));

        btnback.setBackground(new java.awt.Color(0, 102, 102));
        btnback.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnbackMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnbackMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnbackMouseExited(evt);
            }
        });
        btnback.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome4.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/back1.png"))); // NOI18N
        btnlblhome4.setText("  Back");
        btnback.add(btnlblhome4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 160, 40));

        btnlogout.setBackground(new java.awt.Color(0, 102, 102));
        btnlogout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnlogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnlogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnlogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnlogoutMouseExited(evt);
            }
        });
        btnlogout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome5.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/logout.png"))); // NOI18N
        btnlblhome5.setText("Logout");
        btnlogout.add(btnlblhome5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 110, 40));

        pnlsidebar.add(btnlogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 160, 40));

        getContentPane().add(pnlsidebar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnhomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnhome.setBackground(clr);
    }//GEN-LAST:event_btnhomeMouseEntered

    private void btnhomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseExited
        // TODO add your handling code here:
         Color clr = new Color(0,103,103);
        btnhome.setBackground(clr);
    }//GEN-LAST:event_btnhomeMouseExited

    private void btnsearchMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btnsearch.setBackground(clr);
    }//GEN-LAST:event_btnsearchMouseEntered

    private void btnsearchMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnsearch.setBackground(clr);
    }//GEN-LAST:event_btnsearchMouseExited

    private void btneditMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btnedit.setBackground(clr);
    }//GEN-LAST:event_btneditMouseEntered

    private void btneditMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnedit.setBackground(clr);
    }//GEN-LAST:event_btneditMouseExited

    private void btncourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btncourse.setBackground(clr);
    }//GEN-LAST:event_btncourseMouseEntered

    private void btncourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btncourse.setBackground(clr);
    }//GEN-LAST:event_btncourseMouseExited

    private void btnlogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btnlogout.setBackground(clr);
    }//GEN-LAST:event_btnlogoutMouseEntered

    private void btnlogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnlogout.setBackground(clr);
    }//GEN-LAST:event_btnlogoutMouseExited

    private void btnbackMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btnback.setBackground(clr);
    }//GEN-LAST:event_btnbackMouseEntered

    private void btnbackMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnback.setBackground(clr);
    }//GEN-LAST:event_btnbackMouseExited

    private void btnviewMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseEntered
        // TODO add your handling code here:
         Color clr = new Color(0,153,153);
        btnview.setBackground(clr);
    }//GEN-LAST:event_btnviewMouseEntered

    private void btnviewMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnview.setBackground(clr);
    }//GEN-LAST:event_btnviewMouseExited

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        // TODO add your handling code here:
        if(validation() == true){
            String result =insertData(); 
            if(result.equals("Sucess")){
                JOptionPane.showMessageDialog(this,"Record Insert Successfully");
                PrintReceipt p = new PrintReceipt();
                p.setVisible(true);
                this.dispose();
            }else{
                JOptionPane.showMessageDialog(this,"Record Insertion Failed");
            }
        }
    }//GEN-LAST:event_btn_printActionPerformed

    private void txt_coursenameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_coursenameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_coursenameActionPerformed

    private void txt_recievedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_recievedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_recievedActionPerformed

    private void combo_paymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_paymentActionPerformed
        // TODO add your handling code here:
        if(combo_payment.getSelectedIndex() == 0){
            lbl_dd.setVisible(true);
            txt_dd.setVisible(true);
            lbl_cheque.setVisible(false);
            txt_cheque.setVisible(false);
            lbl_bank.setVisible(true);
            txt_bank.setVisible(true);
        }
          if(combo_payment.getSelectedIndex() == 1){
            lbl_dd.setVisible(false);
            txt_dd.setVisible(false);
            lbl_cheque.setVisible(true);
            txt_cheque.setVisible(true);
            lbl_bank.setVisible(true);
            txt_bank.setVisible(true);
        }
           if(combo_payment.getSelectedIndex() == 2){
            lbl_dd.setVisible(false);
            txt_dd.setVisible(false);
            lbl_cheque.setVisible(false);
            txt_cheque.setVisible(false);
            lbl_bank.setVisible(false);
            txt_bank.setVisible(false);
        }
             if(combo_payment.getSelectedIndex() == 3){
            lbl_dd.setVisible(false);
            txt_dd.setVisible(false);
            lbl_cheque.setVisible(false);
            txt_cheque.setVisible(false);
            lbl_bank.setVisible(true);
            txt_bank.setVisible(true);
        }
    }//GEN-LAST:event_combo_paymentActionPerformed

    private void txt_amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_amountActionPerformed
        // TODO add your handling code here:
        Float amnt = Float.parseFloat(txt_amount.getText());
        
        Float cgst = (float)(amnt * 0.09);
        Float sgst = (float)(amnt * 0.09);
        
        txt_cgst.setText(cgst.toString());
        txt_sgst.setText(sgst.toString());
        
        float total = cgst + sgst +amnt;
        txt_total.setText(Float.toString(total));
        
        txt_totalwords.setText(NumberToWordsConverter.convert((int)total)+ " Only ");
    }//GEN-LAST:event_txt_amountActionPerformed

    private void combo_courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_courseActionPerformed
        // TODO add your handling code here:
        txt_coursename.setText(combo_course.getSelectedItem().toString());
    }//GEN-LAST:event_combo_courseActionPerformed

    private void btnhomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseClicked
        // TODO add your handling code here:
        home home = new home();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnhomeMouseClicked

    private void btnsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseClicked
        // TODO add your handling code here:
        SearchRecords search = new SearchRecords();
        search.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsearchMouseClicked

    private void btneditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseClicked
        // TODO add your handling code here:
        EditCourse edit = new EditCourse();
        edit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btneditMouseClicked

    private void btncourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseClicked
        // TODO add your handling code here:
        EditCourse edit = new EditCourse();
        edit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btncourseMouseClicked

    private void btnviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseClicked
        // TODO add your handling code here:
        ViewAllRecords view = new ViewAllRecords();
        view.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnviewMouseClicked

    private void btnbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseClicked
        // TODO add your handling code here:
        home home = new home();
       home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnbackMouseClicked

    private void btnlogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseClicked
        // TODO add your handling code here:
        login login = new login();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnlogoutMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(addfees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(addfees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(addfees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(addfees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new addfees().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button btn_print;
    private javax.swing.JPanel btnback;
    private javax.swing.JPanel btncourse;
    private javax.swing.JPanel btnedit;
    private javax.swing.JPanel btnhome;
    private javax.swing.JLabel btnlblhome;
    private javax.swing.JLabel btnlblhome1;
    private javax.swing.JLabel btnlblhome2;
    private javax.swing.JLabel btnlblhome3;
    private javax.swing.JLabel btnlblhome4;
    private javax.swing.JLabel btnlblhome5;
    private javax.swing.JLabel btnlblhome6;
    private javax.swing.JPanel btnlogout;
    private javax.swing.JPanel btnsearch;
    private javax.swing.JPanel btnview;
    private javax.swing.JComboBox<String> combo_course;
    private javax.swing.JComboBox<String> combo_payment;
    private com.toedter.calendar.JDateChooser datechooser;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lbl_bank;
    private javax.swing.JLabel lbl_cheque;
    private javax.swing.JLabel lbl_dd;
    private javax.swing.JPanel pnlchild;
    private javax.swing.JPanel pnlparent;
    private javax.swing.JPanel pnlsidebar;
    private javax.swing.JTextField txt_amount;
    private javax.swing.JTextField txt_bank;
    private javax.swing.JTextField txt_cgst;
    private javax.swing.JTextField txt_cheque;
    private javax.swing.JTextField txt_coursename;
    private javax.swing.JTextField txt_dd;
    private javax.swing.JLabel txt_gst;
    private javax.swing.JTextField txt_receipt;
    private javax.swing.JTextField txt_recieved;
    private javax.swing.JTextArea txt_remark;
    private javax.swing.JTextField txt_rollNo;
    private javax.swing.JTextField txt_sgst;
    private javax.swing.JTextField txt_total;
    private javax.swing.JTextField txt_totalwords;
    private javax.swing.JTextField txt_year1;
    private javax.swing.JTextField txt_year2;
    // End of variables declaration//GEN-END:variables
}
