/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fees_management_system;

import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.MessageFormat;
import javax.swing.JFileChooser;
import javax.swing.JTable;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JOptionPane;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;






/**
 *
 * @author Sushant
 */
public class GenerateReport extends javax.swing.JFrame {

    /**
     * Creates new form GenerateReport
     */
    DefaultTableModel model;
    
    public GenerateReport() {
        initComponents();
        fillcombobox();
    }

    public void fillcombobox(){
        try{
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdata","root","root");
             PreparedStatement pst = con.prepareStatement("select cname from course");
             ResultSet rs = pst.executeQuery();
             while(rs.next()){
                 combo_course.addItem(rs.getString("cname"));
             }
           
        }catch(Exception e){
          e.printStackTrace();
        //  e.toString();
          //System.out.println(e);
        }
    }
    public void setRecordTable(){
        String cname = combo_course.getSelectedItem().toString();
        SimpleDateFormat dateformat = new SimpleDateFormat("YYYY-MM-dd");
        String fromDate = dateformat.format(datechooserfrom.getDate());
        String toDate = dateformat.format(datechooserto.getDate());
        
        Float amnt = 0.0f;
        
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from fees_details where date between ? and ? and courses = ?");
            
            pst.setString(1,fromDate);
            pst.setString(2,toDate);
            pst.setString(3,cname);
            
            ResultSet rs = pst.executeQuery();
            
            while(rs.next()){
                String recieptno = rs.getString("reciept_no"); 
                String rollno = rs.getString("roll_no"); 
                String studentname = rs.getString("student_name");
                String coursename = rs.getString("courses");
                float amount = rs.getFloat("total_amount");
                String remark = rs.getString("remark");
               
                amnt = amnt + amount;
                
                Object[] obj ={recieptno,rollno,studentname,coursename,amount,remark};
                
                model = (DefaultTableModel)tbl_report.getModel();
                model.addRow(obj);
            }
            lbl_course.setText(cname);
            lbl_amount.setText(amnt.toString());
            lbl_amountwords.setText(NumberToWordsConverter.convert(amnt.intValue()));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void clearTable(){
      DefaultTableModel model = (DefaultTableModel)tbl_report.getModel();
      model.setRowCount(1); 
    }
    public void ExporttoExcel(){
        XSSFWorkbook wb = new XSSFWorkbook();
        XSSFSheet ws = wb.createSheet();
        DefaultTableModel model = (DefaultTableModel)tbl_report.getModel();
        
        TreeMap<String , Object[]> map = new TreeMap<>();
        
        map.put("0",new Object[]{model.getColumnName(0),model.getColumnName(1),model.getColumnName(2),model.getColumnName(3),
            model.getColumnName(4),model.getColumnName(5)});
        
        for(int i = 1;i<model.getRowCount();i++){
            map.put(Integer.toString(i),new Object[]{model.getValueAt(i,0),model.getValueAt(i,1),model.getValueAt(i,2),
                model.getValueAt(i,3),model.getValueAt(i,4),model.getValueAt(i,5)});
        }
      /*  for(Map.Entry<String,Object[]>entry : map.entrySet()){
            
            String key = entry.getKey();
            Object[] value = entry.getValue();
            
            System.out.println();
        }*/
      
      Set<String>id =map.keySet();
      XSSFRow fRow;
      int rowId =0;
      
      for(String key : id){
          fRow = ws.createRow(rowId++);
          Object [] value =map.get(key);
          int cellId =0;
          
          for(Object object : value){
              XSSFCell cell = fRow.createCell(cellId++);
              cell.setCellValue(object.toString());
              
              
          }
      }
      try(FileOutputStream fos = new FileOutputStream(new File(txt_filepath.getText()))){
         
         wb.write(fos);
        JOptionPane.showMessageDialog(this,"File Exported Succesfully"+txt_filepath.getText());
      }catch(Exception e){
          e.printStackTrace();
      }
      
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlsidebar = new javax.swing.JPanel();
        btnsearch = new javax.swing.JPanel();
        btnlblhome2 = new javax.swing.JLabel();
        btnhome = new javax.swing.JPanel();
        btnlblhome = new javax.swing.JLabel();
        btnedit = new javax.swing.JPanel();
        btnlblhome3 = new javax.swing.JLabel();
        btncourse = new javax.swing.JPanel();
        btnlblhome1 = new javax.swing.JLabel();
        btnview = new javax.swing.JPanel();
        btnlblhome6 = new javax.swing.JLabel();
        btnback = new javax.swing.JPanel();
        btnlblhome4 = new javax.swing.JLabel();
        btnlogout = new javax.swing.JPanel();
        btnlblhome5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        combo_course = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        datechooserto = new com.toedter.calendar.JDateChooser();
        datechooserfrom = new com.toedter.calendar.JDateChooser();
        btn_browser = new javax.swing.JButton();
        btn_submit = new javax.swing.JButton();
        txt_filepath = new javax.swing.JTextField();
        btn_print = new javax.swing.JButton();
        btn_browser1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_report = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        lbl_amountwords = new javax.swing.JLabel();
        lbl_course = new javax.swing.JLabel();
        lbl_amount = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlsidebar.setBackground(new java.awt.Color(0, 102, 102));
        pnlsidebar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnsearch.setBackground(new java.awt.Color(0, 102, 102));
        btnsearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnsearchMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnsearchMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnsearchMouseExited(evt);
            }
        });
        btnsearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome2.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/search3.png"))); // NOI18N
        btnlblhome2.setText("Search");
        btnsearch.add(btnlblhome2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 160, 40));

        btnhome.setBackground(new java.awt.Color(0, 102, 102));
        btnhome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnhome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnhomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnhomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnhomeMouseExited(evt);
            }
        });
        btnhome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/home1.png"))); // NOI18N
        btnlblhome.setText("  Home");
        btnhome.add(btnlblhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 160, 40));

        btnedit.setBackground(new java.awt.Color(0, 102, 102));
        btnedit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btneditMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btneditMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btneditMouseExited(evt);
            }
        });
        btnedit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome3.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/edit1.png"))); // NOI18N
        btnlblhome3.setText("Edit");
        btnedit.add(btnlblhome3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, -1, 40));

        pnlsidebar.add(btnedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 160, 40));

        btncourse.setBackground(new java.awt.Color(0, 102, 102));
        btncourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btncourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btncourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btncourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btncourseMouseExited(evt);
            }
        });
        btncourse.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome1.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/course.png"))); // NOI18N
        btnlblhome1.setText("Course");
        btncourse.add(btnlblhome1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btncourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 160, 40));

        btnview.setBackground(new java.awt.Color(0, 102, 102));
        btnview.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnview.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnviewMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnviewMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnviewMouseExited(evt);
            }
        });
        btnview.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome6.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/view all record.png"))); // NOI18N
        btnlblhome6.setText("Veiw");
        btnview.add(btnlblhome6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnview, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 160, 40));

        btnback.setBackground(new java.awt.Color(0, 102, 102));
        btnback.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnbackMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnbackMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnbackMouseExited(evt);
            }
        });
        btnback.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome4.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/back1.png"))); // NOI18N
        btnlblhome4.setText("  Back");
        btnback.add(btnlblhome4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pnlsidebar.add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 160, 40));

        btnlogout.setBackground(new java.awt.Color(0, 102, 102));
        btnlogout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnlogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnlogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnlogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnlogoutMouseExited(evt);
            }
        });
        btnlogout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnlblhome5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlblhome5.setForeground(new java.awt.Color(255, 255, 255));
        btnlblhome5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/pictures/logout.png"))); // NOI18N
        btnlblhome5.setText("Logout");
        btnlogout.add(btnlblhome5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 110, 40));

        pnlsidebar.add(btnlogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 160, 40));

        getContentPane().add(pnlsidebar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 600));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        combo_course.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        combo_course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_courseActionPerformed(evt);
            }
        });
        jPanel1.add(combo_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 190, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Select Course : ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Select Date : ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("From Date : ");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, -1, -1));
        jPanel1.add(datechooserto, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, -1, -1));
        jPanel1.add(datechooserfrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, -1, -1));

        btn_browser.setBackground(new java.awt.Color(0, 103, 103));
        btn_browser.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_browser.setForeground(new java.awt.Color(255, 255, 255));
        btn_browser.setText("Browser");
        btn_browser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_browserActionPerformed(evt);
            }
        });
        jPanel1.add(btn_browser, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, 100, 30));

        btn_submit.setBackground(new java.awt.Color(0, 103, 103));
        btn_submit.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_submit.setForeground(new java.awt.Color(255, 255, 255));
        btn_submit.setText("Submit");
        btn_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_submitActionPerformed(evt);
            }
        });
        jPanel1.add(btn_submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 100, 30));

        txt_filepath.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_filepath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_filepathActionPerformed(evt);
            }
        });
        jPanel1.add(txt_filepath, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 260, 20));

        btn_print.setBackground(new java.awt.Color(0, 103, 103));
        btn_print.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_print.setForeground(new java.awt.Color(255, 255, 255));
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        jPanel1.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 100, 30));

        btn_browser1.setBackground(new java.awt.Color(0, 103, 103));
        btn_browser1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_browser1.setForeground(new java.awt.Color(255, 255, 255));
        btn_browser1.setText("Export to Excel");
        btn_browser1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_browser1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn_browser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 210, 150, 30));

        tbl_report.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        tbl_report.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "Receipt No.", "Roll No.", "Student Name", "Course", "Amount", "Remark"
            }
        ));
        jScrollPane1.setViewportView(tbl_report);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 910, 310));

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_amountwords.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        lbl_amountwords.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.add(lbl_amountwords, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 310, 20));

        lbl_course.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        lbl_course.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.add(lbl_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 160, 20));

        lbl_amount.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        lbl_amount.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.add(lbl_amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 140, 20));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Course Selected : ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Total Amount Collected : ");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, 20));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Total Amount in Words  : ");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, -1, 130));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("To Date : ");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 940, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseClicked
        // TODO add your handling code here:
        SearchRecords search = new SearchRecords();
        search.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsearchMouseClicked

    private void btnsearchMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnsearch.setBackground(clr);
    }//GEN-LAST:event_btnsearchMouseEntered

    private void btnsearchMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsearchMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnsearch.setBackground(clr);
    }//GEN-LAST:event_btnsearchMouseExited

    private void btnhomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseClicked
        // TODO add your handling code here:
        home home = new home();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnhomeMouseClicked

    private void btnhomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnhome.setBackground(clr);
    }//GEN-LAST:event_btnhomeMouseEntered

    private void btnhomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnhome.setBackground(clr);
    }//GEN-LAST:event_btnhomeMouseExited

    private void btneditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseClicked
        // TODO add your handling code here:
        EditCourse course = new EditCourse();
        course.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btneditMouseClicked

    private void btneditMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnedit.setBackground(clr);
    }//GEN-LAST:event_btneditMouseEntered

    private void btneditMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btneditMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnedit.setBackground(clr);
    }//GEN-LAST:event_btneditMouseExited

    private void btncourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseClicked
        // TODO add your handling code here:
        EditCourse course = new EditCourse();
        course.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btncourseMouseClicked

    private void btncourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btncourse.setBackground(clr);
    }//GEN-LAST:event_btncourseMouseEntered

    private void btncourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncourseMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btncourse.setBackground(clr);
    }//GEN-LAST:event_btncourseMouseExited

    private void btnviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseClicked
        // TODO add your handling code here:
        ViewAllRecords records = new ViewAllRecords();
        records.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnviewMouseClicked

    private void btnviewMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnview.setBackground(clr);
    }//GEN-LAST:event_btnviewMouseEntered

    private void btnviewMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnviewMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnview.setBackground(clr);
    }//GEN-LAST:event_btnviewMouseExited

    private void btnbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseClicked
        // TODO add your handling code here:
        home home = new home();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnbackMouseClicked

    private void btnbackMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnback.setBackground(clr);
    }//GEN-LAST:event_btnbackMouseEntered

    private void btnbackMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnbackMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnback.setBackground(clr);
    }//GEN-LAST:event_btnbackMouseExited

    private void btnlogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseClicked
        // TODO add your handling code here:
        login login = new login();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnlogoutMouseClicked

    private void btnlogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseEntered
        // TODO add your handling code here:
        Color clr = new Color(0,153,153);
        btnlogout.setBackground(clr);
    }//GEN-LAST:event_btnlogoutMouseEntered

    private void btnlogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnlogoutMouseExited
        // TODO add your handling code here:
        Color clr = new Color(0,103,103);
        btnlogout.setBackground(clr);
    }//GEN-LAST:event_btnlogoutMouseExited

    private void btn_browserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_browserActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.showOpenDialog(this);
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
        String date = dateFormat.format(new Date());
        
        try{
            File f = fileChooser.getSelectedFile();
            String path = f.getAbsolutePath();
            
            path = path+"_"+date+".xlsx";
            txt_filepath.setText(path);
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_browserActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        // TODO add your handling code here:
         SimpleDateFormat Date_Format = new SimpleDateFormat("YYYY-MM-dd"); 
        String datefrom=  Date_Format.format(datechooserfrom.getDate());
      String dateto=  Date_Format.format(datechooserto.getDate());
       
        MessageFormat header=new MessageFormat("Report From "+datefrom+" To " +dateto);
MessageFormat footer=new MessageFormat("page{0,number,integer}");
        try {
            tbl_report.print(JTable.PrintMode.FIT_WIDTH, header, footer);
            
        } catch (Exception e) {
            e.getMessage();
        } 
    }//GEN-LAST:event_btn_printActionPerformed

    private void btn_browser1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_browser1ActionPerformed
        // TODO add your handling code here:
        ExporttoExcel();
    }//GEN-LAST:event_btn_browser1ActionPerformed

    private void combo_courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_courseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo_courseActionPerformed

    private void txt_filepathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_filepathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_filepathActionPerformed

    private void btn_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_submitActionPerformed
        // TODO add your handling code here:
        clearTable();
        setRecordTable();
    }//GEN-LAST:event_btn_submitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GenerateReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GenerateReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GenerateReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GenerateReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GenerateReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_browser;
    private javax.swing.JButton btn_browser1;
    private javax.swing.JButton btn_print;
    private javax.swing.JButton btn_submit;
    private javax.swing.JPanel btnback;
    private javax.swing.JPanel btncourse;
    private javax.swing.JPanel btnedit;
    private javax.swing.JPanel btnhome;
    private javax.swing.JLabel btnlblhome;
    private javax.swing.JLabel btnlblhome1;
    private javax.swing.JLabel btnlblhome2;
    private javax.swing.JLabel btnlblhome3;
    private javax.swing.JLabel btnlblhome4;
    private javax.swing.JLabel btnlblhome5;
    private javax.swing.JLabel btnlblhome6;
    private javax.swing.JPanel btnlogout;
    private javax.swing.JPanel btnsearch;
    private javax.swing.JPanel btnview;
    private javax.swing.JComboBox<String> combo_course;
    private com.toedter.calendar.JDateChooser datechooserfrom;
    private com.toedter.calendar.JDateChooser datechooserto;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_amount;
    private javax.swing.JLabel lbl_amountwords;
    private javax.swing.JLabel lbl_course;
    private javax.swing.JPanel pnlsidebar;
    private javax.swing.JTable tbl_report;
    private javax.swing.JTextField txt_filepath;
    // End of variables declaration//GEN-END:variables
}
